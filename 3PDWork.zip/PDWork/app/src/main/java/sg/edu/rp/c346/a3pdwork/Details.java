package sg.edu.rp.c346.a3pdwork;

public class Details {
    int pic;
    String name;
    String phoneNum;
    String rate;
    String speciality;
    String Recommendations;

    public Details(int pic,String name, String phoneNum, String rate, String speciality, String recommendations) {
        this.pic = pic;
        this.name = name;
        this.phoneNum = phoneNum;
        this.rate = rate;
        this.speciality = speciality;
        Recommendations = recommendations;

    }

    public int getPic() {
        return pic;
    }

    public void setPic(int pic) {
        this.pic = pic;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public String getRecommendations() {
        return Recommendations;
    }

    public void setRecommendations(String recommendations) {
        Recommendations = recommendations;
    }
}
